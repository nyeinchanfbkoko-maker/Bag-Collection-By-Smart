type SearchableCustomer = { id: string; name: string; phone: string; address?: string };
const normalize = (value: string) => value.normalize("NFC").trim().toLowerCase();
const phoneDigits = (value: string) => value.replace(/[၀-၉]/g, (digit) => String(digit.charCodeAt(0) - 0x1040)).replace(/\D/g, "");

export function filterCustomers<T extends SearchableCustomer>(customers: readonly T[], query: string): T[] {
  const text = normalize(query);
  if (!text) return [...customers];
  const numericQuery = /^[0-9၀-၉\s()+.\-]+$/.test(text) ? phoneDigits(text) : "";
  return customers.map((customer, index) => {
    const name = normalize(customer.name);
    const rank = name.startsWith(text) ? 0 : name.includes(text) ? 1 : numericQuery && phoneDigits(customer.phone).includes(numericQuery) ? 2 : -1;
    return { customer, index, rank };
  }).filter((entry) => entry.rank >= 0).sort((a, b) => a.rank - b.rank || a.index - b.index).map((entry) => entry.customer);
}
