export type CustomerDraft = { name: string; phone: string; address: string; remark?: string };
export type CustomerRecord = CustomerDraft & { id: string; code: string };

/** Keep validation shared by every customer-entry screen. */
export function createCustomerRecord(
  draft: CustomerDraft,
  now = Date.now(),
  random = Math.random(),
): CustomerRecord {
  const name = draft.name.trim();
  if (!name) throw new Error("ဝယ်သူအမည် ထည့်ပေးပါ။");
  const suffix = random.toString(36).slice(2, 8).padEnd(6, "0");
  return {
    id: `c${now}-${suffix}`,
    code: `bcbs${String(now).slice(-8)}-${suffix}`,
    name,
    phone: draft.phone.trim(),
    address: draft.address.trim(),
    remark: (draft.remark ?? "").trim(),
  };
}
