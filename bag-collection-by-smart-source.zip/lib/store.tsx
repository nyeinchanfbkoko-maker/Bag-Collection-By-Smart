import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import { createCustomerRecord } from "@/lib/customer";

export type Customer = { id: string; name: string; address: string; phone: string; code: string; remark?: string };
export type PriceTier = "Retail" | "Wholesale";
export type StockItem = { id: string; item: string; qty: number; sold: number; minimum: number; retailPrice: number; wholesalePrice: number };
export type SaleLine = { id: string; invoiceId: string; customerId: string; item: string; qty: number; price: number; retailPrice: number; wholesalePrice: number; priceTier: PriceTier; date: string; payment: "Cash" | "COD" | "Credit"; paid: number };

export type Shop = { name: string; tagline: string; phone: string; address: string };
type StoreState = { customers: Customer[]; sales: SaleLine[]; stock: StockItem[]; activeInvoiceId: string; shop: Shop };
const STORAGE_KEY = "bag-collection-smart:v1";
export const GOOGLE_SHEETS_SYNC_URL = "https://script.google.com/macros/s/AKfycbzE0K5HHcBWIgsZDYCGcNAHg7AnIyDXaVS1Fh9MUKMbOsQ-OFLVXEhDQRyHtTIU2yys/exec";
const today = new Date().toISOString().slice(0, 10);
const seedCustomers: Customer[] = [
  { id: "c1", name: "MgMg", address: "တောင်ငူမြို့", phone: "09-96743674366", code: "bcbs260405", remark: "Royal / Cash On" },
  { id: "c2", name: "Hla Hla", address: "မုဒုံလေးရပ်ကွက်", phone: "09-92466382873", code: "bcbs260406", remark: "COD" },
  { id: "c3", name: "Tun Tun", address: "ရန်ကုန်", phone: "09-467866788", code: "bcbs260407", remark: "Royal" },
  { id: "c4", name: "Thein Thein", address: "ပုဇွန်တောင်ရန်ကုန်", phone: "9554478989", code: "bcbs260408", remark: "Cash on Delivery" },
  { id: "c5", name: "War War", address: "", phone: "", code: "bcbs260409", remark: "" },
];
const seedStock: StockItem[] = [
  ["Ck. အစုံ", 50, 15, 10, 45000, 40000], ["Pedroအလှ", 42, 8, 10, 50000, 45000], ["Lv2ခရမ်း", 35, 10, 8, 20000, 18000], ["Guess shoulder", 28, 6, 8, 45000, 40000], ["prada", 25, 6, 8, 50000, 45000], ["Cksho", 30, 2, 8, 50000, 45000], ["guess အစုံ", 22, 4, 8, 35000, 30000],
].map(([item, qty, sold, minimum, retailPrice, wholesalePrice], index) => ({ id: `i${index + 1}`, item: item as string, qty: qty as number, sold: sold as number, minimum: minimum as number, retailPrice: retailPrice as number, wholesalePrice: wholesalePrice as number }));
const defaultInvoiceId = `inv-${today}-001`;
const seedSales: SaleLine[] = [
  ["MgMg", "Ck. အစုံ", 5, 45000], ["Hla Hla", "Pedroအလှ", 4, 50000], ["Hla Hla", "Lv2ခရမ်း", 5, 20000], ["Tun Tun", "Cksho", 2, 50000], ["Tun Tun", "Pedro s", 4, 40000], ["Thein Thein", "Guess shoulder", 2, 45000], ["Thein Thein", "prada", 2, 50000], ["War War", "guess အစုံ", 2, 35000],
].map(([name, item, qty, price], index) => ({ id: `s${index + 1}`, invoiceId: defaultInvoiceId, customerId: seedCustomers.find((c) => c.name === name)?.id ?? "c1", item: item as string, qty: qty as number, price: price as number, retailPrice: price as number, wholesalePrice: Math.max(0, (price as number) - 5000), priceTier: "Retail" as PriceTier, date: today, payment: "Cash" as const, paid: (price as number) * (qty as number) }));
const seedState: StoreState = { customers: seedCustomers, sales: seedSales, stock: seedStock, activeInvoiceId: defaultInvoiceId, shop: { name: "Bag Collection By Smart", tagline: "စက်ရုံတိုက်ရိုက် အိတ်လက်လီ/လက္ကား ဖြန့်ချီရေး", phone: "09-000000000", address: "ဆိုင်လိပ်စာ မထည့်ရသေး" } };

type SyncJob = { id: string; sheet: "Sales" | "Customers" | "Stock" | "Invoices"; row: (string | number)[] };
type StoreValue = StoreState & { hydrated: boolean; syncPending: number; syncNow: () => Promise<void>; addCustomer: (customer: Omit<Customer, "id" | "code">) => Customer; addSale: (sale: Omit<SaleLine, "id">) => void; addStock: (stock: Omit<StockItem, "id" | "sold">) => void; startNewInvoice: () => void; setActiveInvoice: (id: string) => void; setShop: (shop: Shop) => void };
const StoreContext = createContext<StoreValue | null>(null);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<StoreState>(seedState);
  const [hydrated, setHydrated] = useState(false);
  const [syncQueue, setSyncQueue] = useState<SyncJob[]>([]);
  useEffect(() => {
    let active = true;
    AsyncStorage.getItem(STORAGE_KEY).then((raw) => {
      if (!active) return;
      if (raw) {
        try {
          const parsed = JSON.parse(raw);
          const sales = Array.isArray(parsed?.sales) ? parsed.sales.map((sale: Partial<SaleLine>, index: number) => ({ ...sale, id: sale.id ?? `s${index + 1}`, invoiceId: sale.invoiceId ?? defaultInvoiceId, retailPrice: sale.retailPrice ?? sale.price ?? 0, wholesalePrice: sale.wholesalePrice ?? sale.price ?? 0, priceTier: sale.priceTier ?? "Retail", paid: sale.paid ?? (sale.qty ?? 0) * (sale.price ?? 0) })) : seedState.sales;
          setState({ ...seedState, ...parsed, customers: Array.isArray(parsed?.customers) ? parsed.customers : seedState.customers, sales, stock: Array.isArray(parsed?.stock) ? parsed.stock : seedState.stock, activeInvoiceId: parsed?.activeInvoiceId ?? defaultInvoiceId, shop: { ...seedState.shop, ...(parsed?.shop ?? {}), tagline: parsed?.shop?.tagline ?? seedState.shop.tagline } });
          setSyncQueue(Array.isArray(parsed?.syncQueue) ? parsed.syncQueue : []);
        } catch { setState(seedState); }
      }
    }).catch(() => { if (active) setState(seedState); }).finally(() => { if (active) setHydrated(true); });
    return () => { active = false; };
  }, []);
  useEffect(() => { if (hydrated) AsyncStorage.setItem(STORAGE_KEY, JSON.stringify({ ...state, syncQueue })).catch(() => undefined); }, [state, syncQueue, hydrated]);
  const enqueue = (job: Omit<SyncJob, "id">) => setSyncQueue((previous) => [...previous, { ...job, id: `${Date.now()}-${Math.random().toString(36).slice(2)}` }]);
  const syncNow = async () => {
    if (!syncQueue.length) return;
    const completed: string[] = [];
    for (const job of syncQueue) {
      try { const response = await fetch(GOOGLE_SHEETS_SYNC_URL, { method: "POST", headers: { "Content-Type": "text/plain;charset=utf-8" }, body: JSON.stringify(job) }); if (response.ok) completed.push(job.id); } catch { break; }
    }
    if (completed.length) setSyncQueue((previous) => previous.filter((job) => !completed.includes(job.id)));
  };
  useEffect(() => { if (hydrated && syncQueue.length) { void syncNow(); } }, [hydrated, syncQueue.length]);
  const value = useMemo<StoreValue>(() => ({
    ...state, hydrated, syncPending: syncQueue.length, syncNow,
    addCustomer: (customer) => { if (!hydrated) throw new Error("စာရင်းဖတ်နေပါသည်။ ခဏစောင့်ပြီး ပြန်သိမ်းပါ။"); const saved = createCustomerRecord(customer); setState((prev) => ({ ...prev, customers: [...prev.customers, saved] })); enqueue({ sheet: "Customers", row: [saved.id, saved.name, saved.address, saved.phone, saved.code, saved.remark ?? ""] }); return saved; },
    addStock: (stock) => { const saved = { ...stock, id: `i${Date.now()}`, sold: 0 }; setState((prev) => ({ ...prev, stock: [...prev.stock, saved] })); enqueue({ sheet: "Stock", row: [saved.id, saved.item, saved.qty, saved.sold, saved.qty - saved.sold, saved.retailPrice, saved.wholesalePrice, saved.minimum] }); },
    addSale: (sale) => { const saved = { ...sale, id: `s${Date.now()}` }; setState((prev) => ({ ...prev, sales: [...prev.sales, saved], stock: prev.stock.map((row) => row.item.toLowerCase() === sale.item.toLowerCase() ? { ...row, sold: row.sold + sale.qty } : row) })); const total = saved.qty * saved.price; const customer = state.customers.find((item) => item.id === saved.customerId); enqueue({ sheet: "Sales", row: [saved.id, saved.invoiceId, saved.date, customer?.name ?? "", customer?.phone ?? "", saved.item, saved.qty, saved.priceTier, saved.price, total, saved.payment, saved.paid, total - saved.paid] }); enqueue({ sheet: "Invoices", row: [saved.invoiceId, saved.date, customer?.name ?? "", saved.qty, total, saved.paid, total - saved.paid] }); },
    startNewInvoice: () => setState((prev) => { const next = prev.sales.length + 1; return { ...prev, activeInvoiceId: `inv-${new Date().toISOString().slice(0, 10)}-${String(next).padStart(3, "0")}` }; }),
    setActiveInvoice: (id) => setState((prev) => ({ ...prev, activeInvoiceId: id })),
    setShop: (shop) => setState((prev) => ({ ...prev, shop })),
  }), [state, hydrated]);
  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}
export function useStore() { const value = useContext(StoreContext); if (!value) throw new Error("useStore must be used inside StoreProvider"); return value; }
export function formatMMK(value: number) { return `${Math.round(value).toLocaleString("en-US")} Ks`; }
export function customerTotal(sales: SaleLine[], customerId: string) { return sales.filter((sale) => sale.customerId === customerId).reduce((sum, sale) => sum + sale.qty * sale.price, 0); }
export function customerDue(sales: SaleLine[], customerId: string) { return sales.filter((sale) => sale.customerId === customerId).reduce((sum, sale) => sum + (sale.qty * sale.price - (sale.paid ?? sale.qty * sale.price)), 0); }
