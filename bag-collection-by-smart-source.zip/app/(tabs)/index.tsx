import { ScrollView, Text, View, Pressable, StyleSheet } from "react-native";
import { Link } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useStore, formatMMK } from "@/lib/store";

const coral = "#F05A5A";
const navy = "#18222F";

export default function HomeScreen() {
  const { customers, sales } = useStore();
  const total = sales.reduce((sum, sale) => sum + sale.qty * sale.price, 0);
  const qty = sales.reduce((sum, sale) => sum + sale.qty, 0);
  const customerIds = new Set(sales.map((sale) => sale.customerId));
  const stockUnits = 248 - qty;

  return (
    <ScreenContainer containerClassName="bg-[#F6F7F9]" className="px-5">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <View>
            <Text style={styles.eyebrow}>BAG COLLECTION BY SMART</Text>
            <Text style={styles.title}>အရောင်း စီမံခန့်ခွဲမှု</Text>
            <Text style={styles.caption}>ဝယ်သူအမည်အလိုက် ဘောင်ချာခွဲထုတ်ပါ</Text>
          </View>
          <View style={styles.avatar}><Text style={styles.avatarText}>BS</Text></View>
        </View>

        <View style={styles.heroCard}>
          <View style={{ flex: 1 }}>
            <Text style={styles.heroLabel}>ယနေ့ အရောင်းစုစုပေါင်း</Text>
            <Text style={styles.heroValue}>{formatMMK(total)}</Text>
            <Text style={styles.heroMeta}>စာရင်း {sales.length} ကြောင်း · Qty {qty}</Text>
          </View>
          <View style={styles.heroBadge}><Text style={styles.heroBadgeText}>● LIVE</Text></View>
        </View>

        <View style={styles.metricGrid}>
          <Metric label="ဝယ်သူ" value={String(customerIds.size)} hint="အရောင်းရှိသူ" accent="#E7F2FF" icon="01" />
          <Metric label="Stock လက်ကျန်" value={String(stockUnits)} hint="units" accent="#FFF2E4" icon="02" />
          <Metric label="ဘောင်ချာ" value={String(new Set(sales.map((sale) => sale.date)).size)} hint="ဒီနေ့" accent="#EAF8EF" icon="03" />
          <Metric label="Item အမျိုးအစား" value={String(new Set(sales.map((sale) => sale.item)).size)} hint="မျိုး" accent="#F3ECFF" icon="04" />
        </View>

        <View style={styles.sectionRow}><Text style={styles.sectionTitle}>အမြန်လုပ်ဆောင်ချက်</Text><Text style={styles.sectionHint}>လွယ်ကူမြန်ဆန်</Text></View>
        <View style={styles.quickGrid}>
          <Link href="/(tabs)/sales" asChild><Pressable style={({ pressed }) => [styles.quickCard, pressed && styles.pressed]}><Text style={styles.quickIcon}>＋</Text><Text style={styles.quickText}>အရောင်းထည့်ရန်</Text><Text style={styles.quickSub}>ဝယ်သူ + Item</Text></Pressable></Link>
          <Link href="/(tabs)/invoice" asChild><Pressable style={({ pressed }) => [styles.quickCard, pressed && styles.pressed]}><Text style={[styles.quickIcon, { color: navy }]}>▤</Text><Text style={styles.quickText}>ဘောင်ချာထုတ်ရန်</Text><Text style={styles.quickSub}>PDF / Share</Text></Pressable></Link>
          <Link href="/(tabs)/customers" asChild><Pressable style={({ pressed }) => [styles.quickCard, pressed && styles.pressed]}><Text style={[styles.quickIcon, { color: "#3B82F6" }]}>♙</Text><Text style={styles.quickText}>ဝယ်သူအသစ်</Text><Text style={styles.quickSub}>အချက်အလက်သိမ်း</Text></Pressable></Link>
          <Link href="/(tabs)/stock" asChild><Pressable style={({ pressed }) => [styles.quickCard, pressed && styles.pressed]}><Text style={[styles.quickIcon, { color: "#F59E0B" }]}>↥</Text><Text style={styles.quickText}>Stock အဝင်</Text><Text style={styles.quickSub}>လက်ကျန်တိုးရန်</Text></Pressable></Link>
        </View>

        <View style={styles.sectionRow}><Text style={styles.sectionTitle}>နောက်ဆုံးအရောင်း</Text><Link href="/(tabs)/sales" style={styles.seeAll}>အားလုံးကြည့်ရန် ›</Link></View>
        <View style={styles.listCard}>
          {sales.slice(-4).reverse().map((sale) => {
            const customer = customers.find((item) => item.id === sale.customerId);
            return <View key={sale.id} style={styles.saleRow}><View style={styles.itemDot}><Text style={styles.itemDotText}>{(customer?.name ?? "?").slice(0, 1)}</Text></View><View style={{ flex: 1 }}><Text style={styles.saleName}>{customer?.name ?? "Unknown"}</Text><Text style={styles.saleItem}>{sale.item} · Qty {sale.qty}</Text></View><Text style={styles.saleAmount}>{formatMMK(sale.qty * sale.price)}</Text></View>;
          })}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

function Metric({ label, value, hint, accent, icon }: { label: string; value: string; hint: string; accent: string; icon: string }) {
  return <View style={styles.metric}><View style={[styles.metricIcon, { backgroundColor: accent }]}><Text style={styles.metricIconText}>{icon}</Text></View><Text style={styles.metricLabel}>{label}</Text><Text style={styles.metricValue}>{value}</Text><Text style={styles.metricHint}>{hint}</Text></View>;
}

const styles = StyleSheet.create({
  content: { paddingTop: 16, paddingBottom: 34 }, header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }, eyebrow: { fontSize: 10, fontWeight: "800", letterSpacing: 1.1, color: coral }, title: { fontSize: 26, fontWeight: "900", color: navy, marginTop: 4 }, caption: { color: "#718096", fontSize: 12, marginTop: 3 }, avatar: { width: 44, height: 44, borderRadius: 15, backgroundColor: navy, alignItems: "center", justifyContent: "center" }, avatarText: { color: "#fff", fontWeight: "900", fontSize: 14 }, heroCard: { backgroundColor: navy, borderRadius: 24, padding: 21, flexDirection: "row", alignItems: "flex-start", marginBottom: 15, shadowColor: navy, shadowOpacity: 0.18, shadowRadius: 14, shadowOffset: { width: 0, height: 7 }, elevation: 5 }, heroLabel: { color: "#B6C2D1", fontSize: 12, fontWeight: "700" }, heroValue: { color: "#fff", fontSize: 27, fontWeight: "900", marginTop: 8 }, heroMeta: { color: "#8290A2", fontSize: 11, marginTop: 7 }, heroBadge: { backgroundColor: "#253448", paddingHorizontal: 9, paddingVertical: 6, borderRadius: 10 }, heroBadgeText: { color: "#7EE2A8", fontSize: 10, fontWeight: "800" }, metricGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10, marginBottom: 21 }, metric: { backgroundColor: "#fff", borderRadius: 18, padding: 13, width: "48.5%", minHeight: 112 }, metricIcon: { width: 28, height: 28, borderRadius: 9, alignItems: "center", justifyContent: "center", marginBottom: 9 }, metricIconText: { fontSize: 10, color: navy, fontWeight: "900" }, metricLabel: { color: "#7A8594", fontSize: 11, fontWeight: "700" }, metricValue: { fontSize: 22, color: navy, fontWeight: "900", marginTop: 4 }, metricHint: { color: "#A6AFBA", fontSize: 10, marginTop: 2 }, sectionRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }, sectionTitle: { fontSize: 16, color: navy, fontWeight: "900" }, sectionHint: { color: "#9AA3AE", fontSize: 11 }, seeAll: { color: coral, fontWeight: "800", fontSize: 11 }, quickGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10, marginBottom: 22 }, quickCard: { width: "48.5%", backgroundColor: "#fff", borderRadius: 18, padding: 15, minHeight: 104, borderWidth: 1, borderColor: "#EEF0F3" }, pressed: { opacity: 0.72, transform: [{ scale: 0.98 }] }, quickIcon: { color: coral, fontSize: 27, fontWeight: "300", lineHeight: 30 }, quickText: { color: navy, fontSize: 12, fontWeight: "900", marginTop: 7 }, quickSub: { color: "#9AA3AE", fontSize: 10, marginTop: 3 }, listCard: { backgroundColor: "#fff", borderRadius: 18, paddingHorizontal: 13, paddingVertical: 4 }, saleRow: { flexDirection: "row", alignItems: "center", paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: "#F0F2F5" }, itemDot: { width: 34, height: 34, borderRadius: 12, backgroundColor: "#FFF0F0", alignItems: "center", justifyContent: "center", marginRight: 10 }, itemDotText: { color: coral, fontWeight: "900" }, saleName: { color: navy, fontSize: 12, fontWeight: "800" }, saleItem: { color: "#8C96A2", fontSize: 10, marginTop: 3 }, saleAmount: { color: navy, fontSize: 11, fontWeight: "900" },
});
