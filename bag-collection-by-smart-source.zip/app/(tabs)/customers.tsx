import { useMemo, useState } from "react";
import { FlatList, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { CustomerFormModal } from "@/components/customer-form-modal";
import { customerDue, customerTotal, formatMMK, useStore } from "@/lib/store";

const navy = "#18222F";
const coral = "#F05A5A";

export default function CustomersScreen() {
  const { customers, sales, hydrated } = useStore();
  const [query, setQuery] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [success, setSuccess] = useState("");
  const filtered = useMemo(() => customers.filter((customer) => `${customer.name} ${customer.phone} ${customer.address}`.toLowerCase().includes(query.toLowerCase())).slice().reverse(), [customers, query]);
  return <ScreenContainer containerClassName="bg-[#F6F7F9]" className="px-5">
    <View style={styles.header}><Text style={styles.eyebrow}>CUSTOMERS</Text><Text style={styles.title}>ဝယ်သူစာရင်း</Text><Text style={styles.caption}>{customers.length} ဦး သိမ်းထားပြီး</Text></View>
    <Pressable accessibilityRole="button" accessibilityLabel="ဝယ်သူအသစ်ထည့်ရန်" disabled={!hydrated} onPress={() => { setSuccess(""); setShowForm(true); }} style={({ pressed }) => [styles.addButton, !hydrated && styles.disabled, pressed && styles.pressed]}><Text style={styles.addButtonText}>＋ ဝယ်သူအသစ်ထည့်ရန်</Text></Pressable>
    {!!success && <Text accessibilityLiveRegion="polite" style={styles.success}>{success}</Text>}
    <View style={styles.search}><Text style={styles.searchIcon}>⌕</Text><TextInput accessibilityLabel="ဝယ်သူရှာရန်" value={query} onChangeText={setQuery} placeholder="အမည် / ဖုန်း / လိပ်စာ ရှာရန်" placeholderTextColor="#A0A8B2" style={styles.searchInput} returnKeyType="search" /></View>
    <FlatList data={filtered} keyExtractor={(item) => item.id} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} contentContainerStyle={styles.listContent} renderItem={({ item, index }) => {
      const total = customerTotal(sales, item.id); const due = customerDue(sales, item.id);
      return <View style={styles.card}><View style={[styles.personCircle, index % 2 ? styles.blueCircle : styles.pinkCircle]}><Text style={[styles.personInitial, index % 2 ? styles.blueText : styles.pinkText]}>{item.name.slice(0, 1)}</Text></View><View style={styles.info}><Text style={styles.name}>{item.name}</Text><Text style={styles.detail}>{item.phone || "ဖုန်းမထည့်ရသေး"} · {item.address || "လိပ်စာမထည့်ရသေး"}</Text><Text style={styles.code}>{item.code} · {item.remark || "မှတ်ချက်မရှိ"}</Text></View><View style={styles.total}><Text style={styles.totalLabel}>ဝယ်ယူမှု</Text><Text style={styles.totalValue}>{formatMMK(total)}</Text><Text style={[styles.dueText, due > 0 ? styles.pinkText : styles.greenText]}>{due > 0 ? `ကျန် ${formatMMK(due)}` : "ရှင်းပြီး"}</Text></View></View>;
    }} ListEmptyComponent={<View style={styles.empty}><Text style={styles.emptyTitle}>ဝယ်သူမတွေ့ပါ</Text><Text style={styles.emptyText}>အပေါ်က ဝယ်သူအသစ်ထည့်ရန် ခလုတ်ကိုနှိပ်ပါ။</Text></View>} />
    <CustomerFormModal visible={showForm} onClose={() => setShowForm(false)} onSaved={(saved) => { setQuery(""); setSuccess(`${saved.name} ကို ဝယ်သူစာရင်းထဲ ထည့်ပြီးပါပြီ။`); }} />
  </ScreenContainer>;
}

const styles = StyleSheet.create({
  header: { paddingTop: 16, paddingBottom: 14 }, eyebrow: { fontSize: 10, fontWeight: "900", color: coral, letterSpacing: 1.2 },
  title: { fontSize: 26, lineHeight: 39, fontWeight: "900", color: navy, marginTop: 4 }, caption: { color: "#8190A2", fontSize: 12, lineHeight: 20, marginTop: 3 },
  addButton: { minHeight: 49, borderRadius: 13, backgroundColor: coral, alignItems: "center", justifyContent: "center", paddingHorizontal: 14, paddingVertical: 10, marginBottom: 14 },
  addButtonText: { color: "#fff", fontSize: 15, lineHeight: 25, fontWeight: "800" }, pressed: { opacity: 0.75 }, disabled: { opacity: 0.5 },
  success: { color: "#166534", backgroundColor: "#EAF8EF", padding: 10, borderRadius: 10, fontSize: 12, lineHeight: 20, marginBottom: 12 },
  search: { height: 45, backgroundColor: "#fff", borderRadius: 14, flexDirection: "row", alignItems: "center", paddingHorizontal: 13, marginBottom: 13, borderWidth: 1, borderColor: "#EEF0F3" },
  searchIcon: { color: coral, fontSize: 25, marginRight: 8 }, searchInput: { flex: 1, color: navy, fontSize: 12 }, listContent: { paddingBottom: 28 },
  card: { backgroundColor: "#fff", borderRadius: 17, padding: 13, marginBottom: 9, flexDirection: "row", alignItems: "center", borderWidth: 1, borderColor: "#EEF0F3" },
  personCircle: { width: 39, height: 39, borderRadius: 14, alignItems: "center", justifyContent: "center", marginRight: 10 },
  pinkCircle: { backgroundColor: "#FFF0F0" }, blueCircle: { backgroundColor: "#EAF2FF" }, pinkText: { color: coral }, blueText: { color: "#3B82F6" }, greenText: { color: "#22A06B" },
  personInitial: { fontSize: 17, fontWeight: "900" }, info: { flex: 1, marginRight: 6 }, name: { color: navy, fontSize: 14, lineHeight: 23, fontWeight: "900" },
  detail: { color: "#7E8A98", fontSize: 10, lineHeight: 17, marginTop: 4 }, code: { color: "#7E8A98", fontSize: 9, lineHeight: 16, marginTop: 4 },
  total: { alignItems: "flex-end" }, totalLabel: { color: "#A3ACB8", fontSize: 9 }, totalValue: { color: navy, fontWeight: "900", fontSize: 11, marginTop: 3 }, dueText: { fontSize: 9, fontWeight: "800", marginTop: 2 },
  empty: { alignItems: "center", paddingTop: 50 }, emptyTitle: { color: navy, fontWeight: "900" }, emptyText: { color: "#8E99A6", fontSize: 12, lineHeight: 20, marginTop: 6 },
});
