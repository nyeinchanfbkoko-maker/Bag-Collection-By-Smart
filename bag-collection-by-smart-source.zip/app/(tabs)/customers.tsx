import { useMemo, useState } from "react";
import { FlatList, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { customerDue, customerTotal, formatMMK, useStore } from "@/lib/store";

const navy = "#18222F";
const coral = "#F05A5A";

export default function CustomersScreen() {
  const { customers, sales, addCustomer } = useStore();
  const [query, setQuery] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const filtered = useMemo(() => customers.filter((customer) => `${customer.name} ${customer.phone} ${customer.address}`.toLowerCase().includes(query.toLowerCase())), [customers, query]);

  const save = () => {
    if (!name.trim()) return;
    addCustomer({ name: name.trim(), phone: phone.trim(), address: address.trim(), remark: "" });
    setName(""); setPhone(""); setAddress(""); setShowForm(false);
  };

  return <ScreenContainer containerClassName="bg-[#F6F7F9]" className="px-5">
    <View style={styles.header}><View><Text style={styles.eyebrow}>CUSTOMERS</Text><Text style={styles.title}>ဝယ်သူစာရင်း</Text><Text style={styles.caption}>{customers.length} ဦး သိမ်းထားပြီး</Text></View><Pressable onPress={() => setShowForm((value) => !value)} style={({ pressed }) => [styles.addButton, pressed && { opacity: 0.75 }]}><Text style={styles.addButtonText}>{showForm ? "×" : "+"}</Text></Pressable></View>
    {showForm && <View style={styles.form}><Text style={styles.formTitle}>ဝယ်သူအသစ်ထည့်ရန်</Text><TextInput value={name} onChangeText={setName} placeholder="အမည် *" placeholderTextColor="#9AA3AE" style={styles.input} /><TextInput value={phone} onChangeText={setPhone} placeholder="ဖုန်းနံပါတ်" placeholderTextColor="#9AA3AE" keyboardType="phone-pad" style={styles.input} /><TextInput value={address} onChangeText={setAddress} placeholder="လိပ်စာ" placeholderTextColor="#9AA3AE" style={styles.input} /><Pressable onPress={save} style={styles.saveButton}><Text style={styles.saveText}>သိမ်းမည်</Text></Pressable></View>}
    <View style={styles.search}><Text style={styles.searchIcon}>⌕</Text><TextInput value={query} onChangeText={setQuery} placeholder="အမည် / ဖုန်း / လိပ်စာ ရှာရန်" placeholderTextColor="#A0A8B2" style={styles.searchInput} /></View>
    <FlatList data={filtered} keyExtractor={(item) => item.id} showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 28 }} renderItem={({ item, index }) => { const total = customerTotal(sales, item.id); const due = customerDue(sales, item.id); return <View style={styles.card}><View style={[styles.personCircle, { backgroundColor: index % 2 ? "#EAF2FF" : "#FFF0F0" }]}><Text style={[styles.personInitial, { color: index % 2 ? "#3B82F6" : coral }]}>{item.name.slice(0, 1)}</Text></View><View style={{ flex: 1 }}><Text style={styles.name}>{item.name}</Text><Text style={styles.detail}>{item.phone || "ဖုန်းမထည့်ရသေး"} · {item.address || "လိပ်စာမထည့်ရသေး"}</Text><Text style={styles.code}>{item.code} · {item.remark || "မှတ်ချက်မရှိ"}</Text></View><View style={styles.total}><Text style={styles.totalLabel}>ဝယ်ယူမှု</Text><Text style={styles.totalValue}>{formatMMK(total)}</Text><Text style={[styles.dueText, { color: due > 0 ? coral : "#22A06B" }]}>{due > 0 ? `ကျန် ${formatMMK(due)}` : "ရှင်းပြီး"}</Text><Text style={styles.chevron}>›</Text></View></View>; }} ListEmptyComponent={<View style={styles.empty}><Text style={styles.emptyTitle}>ရှာဖွေမှုမတွေ့ပါ</Text><Text style={styles.emptyText}>အမည်အသစ်ထည့်ရန် + ကိုနှိပ်ပါ</Text></View>} />
  </ScreenContainer>;
}

const styles = StyleSheet.create({ header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingTop: 16, paddingBottom: 16 }, eyebrow: { fontSize: 10, fontWeight: "900", color: coral, letterSpacing: 1.2 }, title: { fontSize: 26, fontWeight: "900", color: navy, marginTop: 4 }, caption: { color: "#8190A2", fontSize: 12, marginTop: 3 }, addButton: { width: 43, height: 43, borderRadius: 14, backgroundColor: coral, alignItems: "center", justifyContent: "center" }, addButtonText: { color: "#fff", fontSize: 27, fontWeight: "300", marginTop: -2 }, form: { backgroundColor: "#fff", padding: 15, borderRadius: 18, marginBottom: 13, borderWidth: 1, borderColor: "#F2D7D7" }, formTitle: { color: navy, fontWeight: "900", fontSize: 14, marginBottom: 10 }, input: { backgroundColor: "#F6F7F9", borderRadius: 11, paddingHorizontal: 13, height: 42, marginBottom: 8, color: navy, fontSize: 12 }, saveButton: { backgroundColor: navy, borderRadius: 11, height: 42, alignItems: "center", justifyContent: "center", marginTop: 2 }, saveText: { color: "#fff", fontWeight: "900", fontSize: 12 }, search: { height: 45, backgroundColor: "#fff", borderRadius: 14, flexDirection: "row", alignItems: "center", paddingHorizontal: 13, marginBottom: 13, borderWidth: 1, borderColor: "#EEF0F3" }, searchIcon: { color: coral, fontSize: 25, marginRight: 8 }, searchInput: { flex: 1, color: navy, fontSize: 12 }, card: { backgroundColor: "#fff", borderRadius: 17, padding: 13, marginBottom: 9, flexDirection: "row", alignItems: "center", borderWidth: 1, borderColor: "#EEF0F3" }, personCircle: { width: 39, height: 39, borderRadius: 14, alignItems: "center", justifyContent: "center", marginRight: 10 }, personInitial: { fontSize: 17, fontWeight: "900" }, name: { color: navy, fontSize: 14, fontWeight: "900" }, detail: { color: "#7E8A98", fontSize: 10, marginTop: 4, maxWidth: 160 }, code: { color: "#A3ACB8", fontSize: 9, marginTop: 4 }, total: { alignItems: "flex-end" }, totalLabel: { color: "#A3ACB8", fontSize: 9 }, totalValue: { color: navy, fontWeight: "900", fontSize: 11, marginTop: 3 }, dueText: { fontSize: 9, fontWeight: "800", marginTop: 2 }, chevron: { color: coral, fontSize: 20, lineHeight: 20, marginTop: 2 }, empty: { alignItems: "center", paddingTop: 75 }, emptyTitle: { color: navy, fontWeight: "900" }, emptyText: { color: "#8E99A6", fontSize: 12, marginTop: 6 }, });
