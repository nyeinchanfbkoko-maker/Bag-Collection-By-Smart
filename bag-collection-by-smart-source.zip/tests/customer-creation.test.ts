import { describe, expect, it, vi } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { createCustomerRecord, type CustomerDraft } from "../lib/customer";

const root = path.resolve(__dirname, "..");
const now = 1_700_000_000_000;
const random = 0.25;

function draft(overrides: Partial<CustomerDraft> = {}): CustomerDraft {
  return {
    name: "မောင်မောင်",
    phone: "09123456789",
    address: "ရန်ကုန်",
    ...overrides,
  };
}

function source(relativePath: string): string {
  return fs.readFileSync(path.join(root, relativePath), "utf8");
}

describe("createCustomerRecord", () => {
  it.each(["", " ", "\t\n\r", "\u00a0\u3000"])(
    "rejects a blank or whitespace-only name (%j) with a Burmese error",
    (name) => {
      expect(() => createCustomerRecord(draft({ name }), now, random)).toThrow(
        /[\u1000-\u109f]/,
      );
    },
  );

  it("trims surrounding whitespace while preserving Burmese text and internal spaces", () => {
    const record = createCustomerRecord(
      draft({
        name: " \tဒေါ် ခင်ခင်အေး\n ",
        phone: "  09 123 456 789  ",
        address: " \nအမှတ် ၁၂၊ ရန်ကုန်\t ",
        remark: " \tပုံမှန် ဝယ်သူ\n ",
      }),
      now,
      random,
    );

    expect(record).toMatchObject({
      name: "ဒေါ် ခင်ခင်အေး",
      phone: "09 123 456 789",
      address: "အမှတ် ၁၂၊ ရန်ကုန်",
      remark: "ပုံမှန် ဝယ်သူ",
    });
  });

  it.each([
    { phone: "", address: "" },
    { phone: " \t ", address: " \n " },
  ])("allows empty optional contact fields (%j)", (contactFields) => {
    const record = createCustomerRecord(draft(contactFields), now, random);

    expect(record.name).toBe("မောင်မောင်");
    expect(record.phone).toBe("");
    expect(record.address).toBe("");
  });

  it("defaults an omitted remark to an empty string", () => {
    const input = draft();
    expect(input).not.toHaveProperty("remark");

    const record = createCustomerRecord(input, now, random);

    expect(record).toHaveProperty("remark", "");
  });

  it.each([undefined, "", " \t\n "])(
    "normalizes an absent or blank remark (%j) to an empty string",
    (remark) => {
      expect(
        createCustomerRecord(draft({ remark }), now, random).remark,
      ).toBe("");
    },
  );

  it("does not mutate the draft while trimming or adding generated fields", () => {
    const input = Object.freeze(
      draft({
        name: " မောင်မောင် ",
        phone: " 09123456789 ",
        address: " ရန်ကုန် ",
        remark: " မှတ်ချက် ",
      }),
    );
    const before = { ...input };

    const record = createCustomerRecord(input, now, random);

    expect(input).toEqual(before);
    expect(input).not.toHaveProperty("id");
    expect(input).not.toHaveProperty("code");
    expect(record).not.toBe(input);
    expect(record.name).toBe("မောင်မောင်");
    expect(record.remark).toBe("မှတ်ချက်");
  });

  it("returns nonempty deterministic IDs and codes for the same injected values", () => {
    const first = createCustomerRecord(draft(), now, random);
    const second = createCustomerRecord(draft(), now, random);

    expect(first.id).toEqual(expect.any(String));
    expect(first.id.length).toBeGreaterThan(0);
    expect(first.code).toEqual(expect.any(String));
    expect(first.code.length).toBeGreaterThan(0);
    expect(second).toEqual(first);
  });

  it("uses randomness to distinguish customers created at the same timestamp", () => {
    const first = createCustomerRecord(draft(), now, 0.125);
    const second = createCustomerRecord(draft(), now, 0.875);

    expect(second.id).not.toBe(first.id);
    expect(second.code).not.toBe(first.code);
  });

  it("uses the timestamp to distinguish customers with the same random value", () => {
    const first = createCustomerRecord(draft(), now, random);
    const second = createCustomerRecord(draft(), now + 1_000, random);

    expect(second.id).not.toBe(first.id);
    expect(second.code).not.toBe(first.code);
  });

  it("defaults to Date.now and Math.random when injection arguments are omitted", () => {
    const expected = createCustomerRecord(draft(), now, random);
    const clock = vi.spyOn(Date, "now").mockReturnValue(now);
    const entropy = vi.spyOn(Math, "random").mockReturnValue(random);

    try {
      expect(createCustomerRecord(draft())).toEqual(expected);
    } finally {
      clock.mockRestore();
      entropy.mockRestore();
    }
  });
});

// These source checks guard integration points without loading React Native,
// touching storage, or performing Google sync. They are not end-to-end UI tests.
describe("customer creation screen wiring", () => {
  it("uses addCustomer and reports the saved customer through onSaved", () => {
    const modal = source("components/customer-form-modal.tsx");

    expect(modal).toMatch(/\baddCustomer\s*\(/);
    expect(modal).toMatch(/\bonSaved\s*\(/);
  });

  it("lets sales select the newly saved customer by ID", () => {
    const sales = source("app/(tabs)/sales.tsx");

    expect(sales).toMatch(/<CustomerFormModal\b/);
    expect(sales).toMatch(/\bonSaved\s*=/);
    expect(sales).toMatch(/\bsetCustomerId\s*\(\s*saved\.id\s*\)/);
  });

  it("exposes the reusable form and Burmese add-customer button on customers", () => {
    const customers = source("app/(tabs)/customers.tsx");

    expect(customers).toMatch(/<CustomerFormModal\b/);
    expect(customers).toContain("ဝယ်သူအသစ်ထည့်ရန်");
  });
});
