import React from "react";
import { renderToString } from "react-dom/server";
import { describe, expect, it, vi } from "vitest";

vi.mock("react-native", () => ({
  Platform: {
    OS: "android",
    select: (options: Record<string, unknown>) => options.android ?? options.default,
  },
  Appearance: { setColorScheme: vi.fn() },
  useColorScheme: () => "light",
  View: ({ children }: { children: React.ReactNode }) =>
    React.createElement("div", null, children),
}));

vi.mock("nativewind", () => ({
  colorScheme: { set: vi.fn() },
  vars: (values: Record<string, string>) => values,
}));

import { ThemeProvider, useThemeContext } from "../lib/theme-provider";

function ThemeConsumer() {
  const { colorScheme } = useThemeContext();
  return React.createElement("span", null, colorScheme);
}

// This exercises React context, not Android native startup.
describe("Theme provider startup regression", () => {
  it("reproduces the original missing-provider error", () => {
    expect(() => renderToString(React.createElement(ThemeConsumer))).toThrow(
      "useThemeContext must be used within ThemeProvider",
    );
  });

  it("renders the consumer when the provider is mounted", () => {
    const html = renderToString(
      React.createElement(ThemeProvider, {
        children: React.createElement(ThemeConsumer),
      }),
    );
    expect(html).toContain("<span>light</span>");
  });
});
