import { describe, expect, it } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { filterCustomers } from "../lib/customer-search";

type Customer = {
  id: string;
  name: string;
  phone: string;
  address?: string;
};

const root = path.resolve(__dirname, "..");

function customer(
  id: string,
  name: string,
  phone = "",
  address?: string,
): Customer {
  return { id, name, phone, address };
}

function ids(customers: readonly Customer[]): string[] {
  return customers.map(({ id }) => id);
}

function source(relativePath: string): string {
  return fs.readFileSync(path.join(root, relativePath), "utf8");
}

describe("filterCustomers", () => {
  it.each(["", " ", "\t\n\r", "\u00a0\u3000"])(
    "returns a new array containing all customers in original order for blank query %j",
    (query) => {
      const customers = [
        customer("z", "Zaw", "09123"),
        customer("a", "Aye"),
        customer("m", "မောင်မောင်", "၀၉၄၅၆"),
      ];

      const result = filterCustomers(customers, query);

      expect(result).toEqual(customers);
      expect(result).not.toBe(customers);
      result.forEach((record, index) => expect(record).toBe(customers[index]));
      result.pop();
      expect(customers).toHaveLength(3);
    },
  );

  it.each(["", "Alice", "123", "၁၂၃"])(
    "returns an empty array for an empty customer list and query %j",
    (query) => {
      expect(filterCustomers([], query)).toEqual([]);
    },
  );

  it("trims the query and matches names case-insensitively anywhere", () => {
    const customers = [
      customer("middle", "Daw ALIce Aye"),
      customer("end", "Ma Alice"),
      customer("other", "Bob"),
    ];

    expect(ids(filterCustomers(customers, " \tAlIcE\n "))).toEqual([
      "middle",
      "end",
    ]);
  });

  it("matches Burmese name fragments without needing a phone number", () => {
    const customers = [
      customer("contains", "ဒေါ် ခင်ခင်အေး"),
      customer("prefix", "ခင်မာ"),
      customer("other", "မောင်မောင်"),
    ];

    expect(ids(filterCustomers(customers, " ခင် "))).toEqual([
      "prefix",
      "contains",
    ]);
  });

  it.each(["Caf\u00e9", "Cafe\u0301"])(
    "normalizes both names and query to Unicode NFC for %j",
    (query) => {
      const customers = [
        customer("contains", "Daw Cafe\u0301"),
        customer("composed", "CAF\u00c9 Aye"),
        customer("decomposed", "Cafe\u0301 Zaw"),
        customer("other", "Coffee"),
      ];

      expect(ids(filterCustomers(customers, query))).toEqual([
        "composed",
        "decomposed",
        "contains",
      ]);
    },
  );

  it("ranks startsWith name matches before contains matches and preserves ties", () => {
    const customers = [
      customer("contains-1", "Ma Aye"),
      customer("prefix-1", "Aye Zaw"),
      customer("contains-2", "Daw Aye Aye"),
      customer("prefix-2", "AYE Hla"),
      customer("unmatched", "Zaw"),
      customer("contains-3", "May Aye"),
    ];

    expect(ids(filterCustomers(customers, "aye"))).toEqual([
      "prefix-1",
      "prefix-2",
      "contains-1",
      "contains-2",
      "contains-3",
    ]);
  });

  it("keeps duplicate names with distinct IDs rather than deduplicating", () => {
    const customers = [
      customer("first", "Aye Aye", "09111"),
      customer("second", "Aye Aye", "09222"),
      customer("third", "Daw Aye Aye", "09333"),
    ];

    expect(ids(filterCustomers(customers, "aye aye"))).toEqual([
      "first",
      "second",
      "third",
    ]);
  });

  it.each(["123456", "၁၂၃၄၅၆", "၁2၃4၅6", " (၁၂၃) - ၄၅၆ ", "123.456"])(
    "matches partial phone digits across ASCII/Myanmar digits and formatting for %j",
    (query) => {
      const customers = [
        customer("ascii", "Zaw", "+95 (09) 123-456-789"),
        customer("myanmar", "Aye", "၀၉ ၁၂၃.၄၅၆ ၇၈၉"),
        customer("mixed", "Hla", "၀9-၁2၃ 4၅6-၇8၉"),
        customer("other", "Mya", "09999888777"),
        customer("empty", "Ko", ""),
      ];

      expect(ids(filterCustomers(customers, query))).toEqual([
        "ascii",
        "myanmar",
        "mixed",
      ]);
    },
  );

  it("matches a numeric fragment in the middle or at the end of a phone", () => {
    const customers = [
      customer("middle", "Zaw", "09123789000"),
      customer("end", "Aye", "09999123789"),
      customer("other", "Hla", "09111000000"),
    ];

    expect(ids(filterCustomers(customers, "23789"))).toEqual(["middle", "end"]);
  });

  it("preserves leading zeroes when normalizing phone digits", () => {
    const customers = [
      customer("match", "Aye", "၀၉-၀၀၁-၂၃၄"),
      customer("other", "Zaw", "091234"),
    ];

    expect(ids(filterCustomers(customers, "၀၀၁"))).toEqual(["match"]);
  });

  it("does not match empty phones or unrelated names for a nonnumeric query", () => {
    const customers = [
      customer("empty", "Bob", ""),
      customer("blank", "Charlie", " \t "),
      customer("punctuation", "David", "()-"),
      customer("phone", "Eve", "09123456789"),
      customer("name", "Alice", ""),
    ];

    expect(ids(filterCustomers(customers, "alice"))).toEqual(["name"]);
    expect(filterCustomers(customers, "not-a-customer")).toEqual([]);
  });

  it("does not reduce a mixed alphanumeric name query to phone digits", () => {
    const customers = [
      customer("name", "Alice2", ""),
      customer("phone-only", "Bob", "09222"),
    ];

    expect(ids(filterCustomers(customers, "alice2"))).toEqual(["name"]);
  });

  it("does not search addresses instead of the requested name or phone fields", () => {
    const customers = [customer("address-only", "Aye", "09123", "Alice Road")];

    expect(filterCustomers(customers, "alice")).toEqual([]);
  });

  it("returns no matches for a numeric query absent from all phones", () => {
    const customers = [customer("number", "Aye", "09123"), customer("empty", "Zaw")];

    expect(filterCustomers(customers, "၈၈၈၈")).toEqual([]);
  });

  it("does not mutate a readonly list or records while normalizing and ranking", () => {
    const customers = Object.freeze([
      Object.freeze(customer("contains", "Daw Cafe\u0301", "၀၉-၁၂၃", " Yangon ")),
      Object.freeze(customer("prefix", "Caf\u00e9", "09 (123)", " Mandalay ")),
    ]);
    const before = customers.map((record) => ({ ...record }));

    expect(ids(filterCustomers(customers, "CAF\u00c9"))).toEqual([
      "prefix",
      "contains",
    ]);
    expect(ids(filterCustomers(customers, "၁၂၃"))).toEqual([
      "contains",
      "prefix",
    ]);
    expect(customers).toEqual(before);
  });

  it("preserves generic customer fields in the returned records", () => {
    const customers = [
      { id: "extended", name: "Aye", phone: "", loyaltyPoints: 42, remark: "Regular" },
    ];

    const result = filterCustomers(customers, "aye");

    expect(result[0].loyaltyPoints).toBe(42);
    expect(result[0].remark).toBe("Regular");
    expect(result[0]).toBe(customers[0]);
  });
});

// Guard integration points without importing React Native or running a browser.
describe("customer search picker wiring", () => {
  it("imports and calls the reusable filterCustomers helper", () => {
    const picker = source("components/customer-search-picker.tsx");

    expect(picker).toMatch(/import\s*\{[^}]*\bfilterCustomers\b[^}]*\}\s*from\s*["'][^"']*customer-search["']/);
    expect(picker).toMatch(/\bfilterCustomers\s*\(/);
  });

  it("renders results with FlatList and keeps handled keyboard taps", () => {
    const picker = source("components/customer-search-picker.tsx");

    expect(picker).toMatch(/<FlatList\b/);
    expect(picker).toMatch(/keyboardShouldPersistTaps\s*=\s*(?:["']handled["']|\{\s*["']handled["']\s*\})/);
  });

  it("imports and renders CustomerSearchPicker on the sales screen", () => {
    const sales = source("app/(tabs)/sales.tsx");

    expect(sales).toMatch(/import\s+(?:\{[^}]*\bCustomerSearchPicker\b[^}]*\}|CustomerSearchPicker)\s+from\s*["'][^"']*customer-search-picker["']/);
    expect(sales).toMatch(/<CustomerSearchPicker\b/);
  });
});
