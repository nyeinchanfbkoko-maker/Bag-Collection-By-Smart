import { describe, expect, it } from "vitest";
import fs from "node:fs";
import path from "node:path";

const root = path.resolve(__dirname, "..");

describe("sales and invoice feature wiring", () => {
  it("includes tier switching, editable price, suggestions, and New invoice flow", () => {
    const source = fs.readFileSync(path.join(root, "app/(tabs)/sales.tsx"), "utf8");
    expect(source).toContain('"Retail", "Wholesale"');
    expect(source).toContain("suggestions");
    expect(source).toContain("onChangeText={setPrice}");
    expect(source).toContain("startNewInvoice");
  });

  it("includes stock retail and wholesale price fields", () => {
    const source = fs.readFileSync(path.join(root, "app/(tabs)/stock.tsx"), "utf8");
    expect(source).toContain("retailPrice");
    expect(source).toContain("wholesalePrice");
    expect(source).toContain("Retail Price");
    expect(source).toContain("Wholesale Price");
  });

  it("previews and prints every invoice page", () => {
    const source = fs.readFileSync(path.join(root, "app/(tabs)/invoice.tsx"), "utf8");
    expect(source).toContain("PAGE_SIZE = 12");
    expect(source).toContain("Previous");
    expect(source).toContain("Next");
    expect(source).toContain("printToFileAsync");
    expect(source).toContain("Array.from({ length: pages }");
  });
});
