import { describe, expect, it } from "vitest";
import fs from "node:fs";
import path from "node:path";

const root = path.resolve(__dirname, "..");

describe("Android startup hardening", () => {
  it("keeps native-only imports out of the icon runtime path", () => {
    const source = fs.readFileSync(path.join(root, "components/ui/icon-symbol.tsx"), "utf8");
    expect(source).toContain('import type { SymbolWeight, SymbolViewProps } from "expo-symbols";');
    expect(source).toContain('MAPPING[name] ?? "help-outline"');
  });

  it("guards persistent storage failures", () => {
    const source = fs.readFileSync(path.join(root, "lib/store.tsx"), "utf8");
    expect(source).toContain(".catch(() => {");
    expect(source).toContain("AsyncStorage.setItem(STORAGE_KEY, JSON.stringify({ ...state, syncQueue }))");
  });

  it("uses stable native release settings", () => {
    const source = fs.readFileSync(path.join(root, "app.config.ts"), "utf8");
    expect(source).toContain("newArchEnabled: true");
    expect(source).toContain("reactCompiler: false");
    expect(source).toContain("versionCode: 5");
    expect(source).not.toContain('"expo-audio"');
    expect(source).not.toContain('"expo-video"');
    expect(source).not.toContain('"expo-build-properties"');
    expect(source).not.toContain('"expo-asset"');
    expect(source).not.toContain('"expo-font"');
    expect(source).not.toContain('"expo-web-browser"');
  });
});
