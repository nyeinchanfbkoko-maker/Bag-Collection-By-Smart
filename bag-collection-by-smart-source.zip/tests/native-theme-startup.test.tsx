import { describe, expect, it, vi } from "vitest";
import React from "react";
import { renderToString } from "react-dom/server";

// Only native UI/platform bindings are mocked. These tests execute the actual
// native useColorScheme/useColors hooks, ThemeProvider and app RootLayout.
// They are React-render regression tests, not emulator/on-device APK tests.
vi.mock("react-native", () => ({
  View: ({ children }: { children?: React.ReactNode }) => React.createElement("div", null, children),
  Appearance: { setColorScheme: vi.fn() },
  useColorScheme: () => "light",
  Platform: { OS: "android", select: (values: Record<string, unknown>) => values.android ?? values.default },
}));
vi.mock("nativewind", () => ({ colorScheme: { set: vi.fn() }, vars: () => ({}) }));
vi.mock("expo-status-bar", () => ({ StatusBar: () => null }));
vi.mock("@/lib/store", () => ({
  StoreProvider: ({ children }: { children?: React.ReactNode }) => React.createElement(React.Fragment, null, children),
}));
vi.mock("expo-router", async () => {
  const { useColors } = await import("../hooks/use-colors");
  return { Stack: () => {
    const colors = useColors();
    return React.createElement("div", null, `native-theme:${colors.background}`);
  } };
});

import { ThemeProvider } from "../lib/theme-provider";
import { useColorScheme } from "../hooks/use-color-scheme";
import RootLayout from "../app/_layout";

function NativeProbe() {
  return React.createElement("span", null, useColorScheme());
}

describe("Android startup theme provider regression", () => {
  it("reproduces the actual missing-provider exception in the native hook", () => {
    expect(() => renderToString(React.createElement(NativeProbe))).toThrow(
      "useThemeContext must be used within ThemeProvider",
    );
  });

  it("the actual ThemeProvider supplies the native hook during render", () => {
    expect(renderToString(React.createElement(ThemeProvider, null, React.createElement(NativeProbe)))).toContain("light");
  });

  it("the actual app root supplies ThemeProvider before native navigation mounts", () => {
    let html = "";
    expect(() => { html = renderToString(React.createElement(RootLayout)); }).not.toThrow();
    expect(html).toContain("native-theme:");
  });
});
