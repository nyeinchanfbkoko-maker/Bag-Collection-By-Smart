import { beforeEach, describe, expect, it, vi } from "vitest";
import React from "react";
import { renderToString } from "react-dom/server";

const fixture = vi.hoisted(() => ({ count: 2 }));

vi.mock("react-native", () => {
  const View = ({ children }: { children?: React.ReactNode }) => React.createElement("div", null, children);
  const Text = ({ children }: { children?: React.ReactNode }) => React.createElement("span", null, children);
  const FlatList = ({ data, renderItem, ListHeaderComponent }: {
    data: unknown[]; renderItem?: (value: { item: unknown; index: number }) => React.ReactNode; ListHeaderComponent?: React.ReactNode;
  }) => {
    // Mirrors the renderer requirement in native VirtualizedListCellRenderer.
    // This is a component-contract regression, not a real-device APK test.
    if (data.length && !renderItem) throw new Error("VirtualizedList: Either ListItemComponent or renderItem props are required but none were found.");
    return React.createElement("div", null, ListHeaderComponent, data.map((item, index) => renderItem?.({ item, index })));
  };
  return { View, Text, Pressable: View, FlatList, Platform: { OS: "android" }, StyleSheet: { create: (value: unknown) => value }, Alert: { alert: vi.fn() } };
});
vi.mock("expo-print", () => ({ printAsync: vi.fn(), printToFileAsync: vi.fn() }));
vi.mock("expo-sharing", () => ({ isAvailableAsync: vi.fn(), shareAsync: vi.fn() }));
vi.mock("@/components/screen-container", () => ({ ScreenContainer: ({ children }: { children?: React.ReactNode }) => React.createElement("main", null, children) }));
vi.mock("@/lib/store", () => ({
  formatMMK: (value: number) => `${value} Ks`,
  useStore: () => ({
    customers: [{ id: "test-buyer", name: "Test Buyer", phone: "", address: "", code: "TEST" }],
    sales: Array.from({ length: fixture.count }, (_, index) => ({ id: `line-${index}`, invoiceId: "test-invoice", customerId: "test-buyer", item: `Synthetic Bag ${index + 1}`, qty: 2, price: 1000 })),
    shop: { name: "Synthetic Shop", tagline: "Test only", address: "Test address" }, activeInvoiceId: "test-invoice",
  }),
}));

import InvoiceScreen from "../app/(tabs)/invoice";

describe("nonempty native invoice renderer regression", () => {
  beforeEach(() => { fixture.count = 2; });
  it("renders nonempty invoice rows without requesting a missing native row renderer", () => {
    const html = renderToString(React.createElement(InvoiceScreen));
    expect(html).toContain("Synthetic Bag 1");
    expect(html).toContain("Synthetic Bag 2");
    expect(html.match(/Synthetic Bag 1</g)).toHaveLength(1);
    expect(html).toContain("4000 Ks");
  });
  it("keeps twelve rows on page one and totals across all thirteen rows", () => {
    fixture.count = 13;
    const html = renderToString(React.createElement(InvoiceScreen));
    expect(html).toContain("Synthetic Bag 12");
    expect(html).not.toContain("Synthetic Bag 13");
    expect(html).toContain("26000 Ks");
    expect(html.replace(/<!--.*?-->/g, "")).toContain("1 / 2");
  });
  it("renders an empty invoice safely", () => {
    fixture.count = 0;
    expect(renderToString(React.createElement(InvoiceScreen))).toContain("0 Ks");
  });
});
