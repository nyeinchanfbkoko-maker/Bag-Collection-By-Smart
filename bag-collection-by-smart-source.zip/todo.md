# Bag Collection by Smart — Feature TODO

- [x] Add stock quantity, retail price, and wholesale price fields.
- [x] Add Retail/Wholesale switch to sales entry.
- [x] Auto-fill stock price by selected tier while keeping price editable.
- [x] Add item-name autocomplete suggestions.
- [x] Add invoice session IDs so New starts a separate receipt and ordinary sales append to the active receipt.
- [x] Add multi-page invoice preview with Previous/Next controls.
- [x] Link Print/PDF to export all invoice pages.
- [ ] Run Android APK build with the updated feature checkpoint.
- [ ] Verify the installed APK on a physical Android phone.
