# Bag Collection by Smart — Feature TODO

- [x] Add stock quantity, retail price, and wholesale price fields.
- [x] Add Retail/Wholesale switch to sales entry.
- [x] Auto-fill stock price by selected tier while keeping price editable.
- [x] Add item-name autocomplete suggestions.
- [x] Add invoice session IDs so New starts a separate receipt and ordinary sales append to the active receipt.
- [x] Add multi-page invoice preview with Previous/Next controls.
- [x] Link Print/PDF to export all invoice pages.
- [x] Make customer creation visible on Customers and Sales screens with a shared keyboard-safe form.
- [x] Validate customer names and auto-select the new customer when created during a sale.
- [x] Verify customer creation, persistence, and invoice selection in the web preview (isolated browser; test requests blocked from live Google Sheets).
- [x] Add sales customer Search bar with partial name matching, formatted ASCII/Myanmar phone matching, clear query, and duplicate-name contact details.
- [x] Keep the searchable result Modal outside the sales FlatList so it scrolls independently; web E2E verifies the 100th result, selection, and preserved sale draft/invoice.
- [x] Reproduce missing ThemeProvider using actual Android theme hooks and root React render, then fix provider wiring (before: throw; after: pass).
- [x] Fix invoice FlatList missing row-renderer contract while preserving the header's paginated invoice layout.
- [x] Preserve package/storage identity and prepare version 1.0.4 / Android versionCode 5 update; retain New Architecture required by Reanimated.
- [ ] Review malformed persisted records and sync-queue validation without clearing or replacing business data (conditional audit finding; not established device crash cause).
- [ ] Run Android APK build with the updated feature checkpoint.
- [ ] Verify the installed APK on a physical Android phone.
