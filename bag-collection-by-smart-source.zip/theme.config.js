/** @type {const} */
const themeColors = {
  primary: { light: '#F05A5A', dark: '#FF7777' },
  background: { light: '#F6F7F9', dark: '#111820' },
  surface: { light: '#FFFFFF', dark: '#1A2530' },
  foreground: { light: '#18222F', dark: '#F4F7FA' },
  muted: { light: '#718096', dark: '#9BAAB8' },
  border: { light: '#E7EBF0', dark: '#334454' },
  success: { light: '#22A06B', dark: '#57D894' },
  warning: { light: '#F59E0B', dark: '#FBBF24' },
  error: { light: '#EF4444', dark: '#F87171' },
};

module.exports = { themeColors };
