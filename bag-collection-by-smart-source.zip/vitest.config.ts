import { defineConfig } from "vitest/config";
import { dirname } from "node:path";
import { fileURLToPath } from "node:url";

export default defineConfig({
  resolve: { alias: { "@": dirname(fileURLToPath(import.meta.url)) } },
  esbuild: { jsx: "automatic" },
  test: { environment: "node" },
});
