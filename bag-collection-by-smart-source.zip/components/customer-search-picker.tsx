import { useMemo, useRef, useState } from "react";
import { FlatList, Keyboard, KeyboardAvoidingView, Modal, Platform, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { filterCustomers } from "@/lib/customer-search";
import type { Customer } from "@/lib/store";

type Props = { customers: Customer[]; selectedId: string; visible: boolean; onClose: () => void; onSelect: (id: string) => void; onAddNew: () => void };

export function CustomerSearchPicker({ customers, selectedId, visible, onClose, onSelect, onAddNew }: Props) {
  const [query, setQuery] = useState("");
  const input = useRef<TextInput>(null);
  const matches = useMemo(() => filterCustomers(customers, query), [customers, query]);
  const close = () => { onClose(); Keyboard.dismiss(); };
  const choose = (id: string) => { onSelect(id); setQuery(""); close(); };

  return (
    <Modal visible={visible} transparent animationType="none" onRequestClose={close} onShow={() => { setQuery(""); input.current?.focus(); }}>
      <ScreenContainer containerClassName="bg-transparent" className="bg-transparent" edges={["top", "bottom", "left", "right"]}>
        <KeyboardAvoidingView style={styles.overlay} behavior={Platform.OS === "ios" ? "padding" : "height"}>
          <Pressable accessibilityRole="button" accessibilityLabel="ဝယ်သူရှာဖွေရေးပိတ်ရန်" onPress={close} style={styles.backdrop} />
          <View style={styles.modalCard}>
            <View style={styles.header}><Text style={styles.title}>ဝယ်သူအမြန်ရှာရန်</Text><Pressable accessibilityRole="button" accessibilityLabel="ဝယ်သူရှာဖွေရလဒ်ပိတ်ရန်" onPress={close} style={styles.close}><Text style={styles.closeText}>ပိတ်မည်</Text></Pressable></View>
            <View style={styles.inputBar}><Text style={styles.searchIcon}>⌕</Text><TextInput ref={input} accessibilityLabel="အရောင်းဝယ်သူရှာရန်" value={query} onChangeText={setQuery} placeholder="ဝယ်သူအမည် / ဖုန်းနံပါတ် ရှာရန်" placeholderTextColor="#8A96A5" style={styles.searchInput} autoCorrect={false} autoCapitalize="none" returnKeyType="search" onSubmitEditing={() => { if (matches.length === 1) choose(matches[0].id); }} />{!!query && <Pressable accessibilityRole="button" accessibilityLabel="ဝယ်သူရှာဖွေမှုရှင်းရန်" onPress={() => { setQuery(""); input.current?.focus(); }} style={({ pressed }) => [styles.clear, pressed && styles.pressed]}><Text style={styles.clearText}>×</Text></Pressable>}</View>
            <Text accessibilityLiveRegion="polite" style={styles.resultCount}>တွေ့ရှိသောဝယ်သူ {matches.length} ဦး</Text>
            <FlatList data={matches} keyExtractor={(customer) => customer.id} style={styles.resultList} keyboardShouldPersistTaps="handled" initialNumToRender={7} maxToRenderPerBatch={10} showsVerticalScrollIndicator renderItem={({ item }) => <Pressable accessibilityRole="button" accessibilityLabel={`ဝယ်သူရွေးရန် ${item.name} ${item.phone}`} onPress={() => choose(item.id)} style={({ pressed }) => [styles.option, item.id === selectedId && styles.activeOption, pressed && styles.pressed]}>
              <View style={styles.grow}><Text style={styles.optionName}>{item.name}</Text><Text style={styles.optionDetail}>{item.phone || "ဖုန်းမထည့်ရသေး"}{item.address ? ` · ${item.address}` : ""}</Text></View>{item.id === selectedId && <Text style={styles.check}>✓</Text>}
            </Pressable>} ListEmptyComponent={<View style={styles.empty}><Text style={styles.emptyTitle}>ဝယ်သူမတွေ့ပါ</Text><Text style={styles.emptyHint}>အမည် / ဖုန်းကို ပြန်စစ်ပါ။ ဝယ်သူအသစ်ဆိုလျှင် အောက်က ခလုတ်ဖြင့် ထည့်နိုင်ပါသည်။</Text><Pressable accessibilityRole="button" accessibilityLabel="ရှာဖွေမှုမှဝယ်သူအသစ်ထည့်ရန်" onPress={() => { close(); onAddNew(); }} style={styles.addNew}><Text style={styles.addNewText}>＋ ဝယ်သူအသစ်ထည့်ရန်</Text></Pressable></View>} />
          </View>
        </KeyboardAvoidingView>
      </ScreenContainer>
    </Modal>
  );
}

export function CustomerSearchBar({ name, onPress }: { name?: string; onPress: () => void }) {
  return <View style={styles.container}>
    <Pressable accessibilityRole="button" accessibilityLabel="ဝယ်သူရှာရန်ဖွင့်မည်" onPress={onPress} style={({ pressed }) => [styles.searchBar, pressed && styles.pressed]}><Text style={styles.searchIcon}>⌕</Text><Text style={styles.placeholder}>ဝယ်သူအမည် / ဖုန်းနံပါတ် ရှာရန်</Text></Pressable>
    <Pressable accessibilityRole="button" accessibilityLabel="ရွေးထားသောဝယ်သူ ပြောင်းရန်" onPress={onPress} style={({ pressed }) => [styles.selected, pressed && styles.pressed]}><View style={styles.grow}><Text style={styles.selectedLabel}>ရွေးထားသောဝယ်သူ</Text><Text style={styles.selectedName}>{name ?? "ဝယ်သူရွေးပါ"}</Text></View><Text style={styles.arrow}>⌄</Text></Pressable>
  </View>;
}

const styles = StyleSheet.create({
  container: { marginBottom: 14 }, grow: { flex: 1 },
  searchBar: { minHeight: 48, flexDirection: "row", alignItems: "center", backgroundColor: "#fff", borderWidth: 1, borderColor: "#CFD8E2", borderRadius: 11, paddingHorizontal: 10 },
  searchIcon: { color: "#F05A5A", fontSize: 27, marginRight: 7 }, placeholder: { color: "#8A96A5", fontSize: 12, lineHeight: 21 },
  selected: { flexDirection: "row", alignItems: "center", backgroundColor: "#F3F5F8", paddingHorizontal: 12, paddingVertical: 8, borderRadius: 10, marginTop: 7 }, selectedLabel: { fontSize: 9, lineHeight: 16, color: "#778494" }, selectedName: { color: "#18222F", fontSize: 13, lineHeight: 22, fontWeight: "700" }, arrow: { color: "#F05A5A", fontSize: 20, paddingLeft: 10 },
  overlay: { flex: 1, justifyContent: "center", paddingHorizontal: 18 }, backdrop: { ...StyleSheet.absoluteFillObject, backgroundColor: "rgba(24,34,47,0.5)" }, modalCard: { backgroundColor: "#fff", borderRadius: 18, padding: 15, maxHeight: "90%", overflow: "hidden" },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }, title: { color: "#18222F", fontSize: 16, lineHeight: 26, fontWeight: "800" }, close: { paddingHorizontal: 10, paddingVertical: 8 }, closeText: { color: "#F05A5A", fontSize: 12, lineHeight: 20, fontWeight: "700" },
  inputBar: { minHeight: 48, flexDirection: "row", alignItems: "center", backgroundColor: "#F6F8FA", borderWidth: 1, borderColor: "#CFD8E2", borderRadius: 10, paddingHorizontal: 10 }, searchInput: { flex: 1, color: "#18222F", fontSize: 12, lineHeight: 21, paddingVertical: 11 }, clear: { width: 34, height: 38, alignItems: "center", justifyContent: "center" }, clearText: { color: "#718096", fontSize: 24 },
  resultCount: { color: "#718096", fontSize: 10, lineHeight: 18, marginVertical: 10 }, resultList: { maxHeight: 330, flexShrink: 1 }, option: { flexDirection: "row", alignItems: "center", paddingHorizontal: 10, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: "#EEF1F4", minHeight: 57 }, activeOption: { backgroundColor: "#FFF4F4" }, optionName: { color: "#18222F", fontSize: 13, lineHeight: 22, fontWeight: "700" }, optionDetail: { color: "#778494", fontSize: 10, lineHeight: 18 }, check: { color: "#F05A5A", fontSize: 17, marginLeft: 10 },
  empty: { padding: 10 }, emptyTitle: { color: "#18222F", fontSize: 13, lineHeight: 22, fontWeight: "700" }, emptyHint: { color: "#778494", fontSize: 11, lineHeight: 20, marginTop: 5 }, addNew: { backgroundColor: "#FFF0F0", padding: 12, borderRadius: 9, alignItems: "center", marginTop: 12 }, addNewText: { color: "#F05A5A", fontSize: 12, lineHeight: 22, fontWeight: "700" }, pressed: { opacity: 0.7 },
});
