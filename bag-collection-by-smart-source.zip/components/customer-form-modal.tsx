import { useEffect, useRef, useState } from "react";
import { Keyboard, KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { type Customer, useStore } from "@/lib/store";

const EMPTY_FORM = { name: "", phone: "", address: "", remark: "" };

type Props = { visible: boolean; onClose: () => void; onSaved: (saved: Customer) => void };

export function CustomerFormModal({ visible, onClose, onSaved }: Props) {
  const { addCustomer, hydrated } = useStore();
  const [form, setForm] = useState(EMPTY_FORM);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const saveLock = useRef(false);
  useEffect(() => {
    if (visible) { setForm(EMPTY_FORM); setError(""); setSaving(false); saveLock.current = false; }
  }, [visible]);
  const save = () => {
    if (!hydrated || saveLock.current) return;
    if (!form.name.trim()) { setError("ဝယ်သူအမည် ထည့်ပေးပါ။"); return; }
    saveLock.current = true;
    setSaving(true);
    try {
      const saved = addCustomer(form);
      Keyboard.dismiss();
      onSaved(saved);
      onClose();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "ဝယ်သူအသစ် သိမ်းမရပါ။ ပြန်ကြိုးစားပါ။");
    } finally { saveLock.current = false; setSaving(false); }
  };
  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose}>
      <ScreenContainer edges={["top", "bottom", "left", "right"]} containerClassName="bg-[#F6F7F9]">
        <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : "height"}>
          <View style={styles.header}>
            <View style={styles.flex}><Text style={styles.title}>ဝယ်သူအသစ်ထည့်ရန်</Text><Text style={styles.caption}>အမည်လိုအပ်ပါသည်။ ကျန်အချက်များကို ချန်ထားနိုင်သည်။</Text></View>
            <Pressable accessibilityRole="button" accessibilityLabel="ဝယ်သူဖောင်ပိတ်ရန်" onPress={onClose} style={({ pressed }) => [styles.close, pressed && styles.pressed]}><Text style={styles.closeText}>ပိတ်မည်</Text></Pressable>
          </View>
          <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={styles.content}>
            <View style={styles.card}>
              <Text style={styles.label}>ဝယ်သူအမည် *</Text>
              <TextInput accessibilityLabel="ဝယ်သူအသစ်အမည်" value={form.name} onChangeText={(name) => { setForm((prev) => ({ ...prev, name })); setError(""); }} placeholder="ဥပမာ — မောင်မောင်" placeholderTextColor="#8895A5" style={[styles.input, !!error && styles.invalid]} maxLength={120} returnKeyType="next" />
              {!!error && <Text accessibilityRole="alert" style={styles.error}>{error}</Text>}
              <Text style={styles.label}>ဖုန်းနံပါတ်</Text>
              <TextInput accessibilityLabel="ဝယ်သူအသစ်ဖုန်းနံပါတ်" value={form.phone} onChangeText={(phone) => setForm((prev) => ({ ...prev, phone }))} placeholder="09…" placeholderTextColor="#8895A5" keyboardType="phone-pad" style={styles.input} maxLength={40} />
              <Text style={styles.label}>လိပ်စာ</Text>
              <TextInput accessibilityLabel="ဝယ်သူအသစ်လိပ်စာ" value={form.address} onChangeText={(address) => setForm((prev) => ({ ...prev, address }))} placeholder="မြို့ / ရပ်ကွက် / လိပ်စာ" placeholderTextColor="#8895A5" style={[styles.input, styles.multiline]} multiline maxLength={500} textAlignVertical="top" />
              <Text style={styles.label}>မှတ်ချက်</Text>
              <TextInput accessibilityLabel="ဝယ်သူအသစ်မှတ်ချက်" value={form.remark} onChangeText={(remark) => setForm((prev) => ({ ...prev, remark }))} placeholder="မဖြစ်မနေ ထည့်ရန်မလိုပါ" placeholderTextColor="#8895A5" style={styles.input} maxLength={300} returnKeyType="done" onSubmitEditing={save} />
              <Text style={styles.note}>သိမ်းပြီးလျှင် ဝယ်သူကုဒ်ကို အလိုအလျောက်ပေးပြီး အရောင်းနှင့် ဘောင်ချာတွင် ရွေးနိုင်ပါမည်။</Text>
              <Pressable accessibilityRole="button" accessibilityLabel="ဝယ်သူအသစ်သိမ်းမည်" disabled={saving || !hydrated} onPress={save} style={({ pressed }) => [styles.save, (saving || !hydrated) && styles.disabled, pressed && styles.pressed]}><Text style={styles.saveText}>{!hydrated ? "စာရင်းဖတ်နေသည်…" : saving ? "သိမ်းနေသည်…" : "ဝယ်သူအသစ်သိမ်းမည်"}</Text></Pressable>
              <Pressable accessibilityRole="button" onPress={onClose} style={styles.cancel}><Text style={styles.cancelText}>မသိမ်းဘဲ ပြန်ထွက်မည်</Text></Pressable>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </ScreenContainer>
    </Modal>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 }, header: { flexDirection: "row", alignItems: "center", padding: 20 },
  title: { color: "#18222F", fontSize: 21, lineHeight: 32, fontWeight: "800" },
  caption: { color: "#748091", fontSize: 11, lineHeight: 19, marginTop: 4, marginRight: 8 },
  close: { paddingHorizontal: 12, paddingVertical: 10, backgroundColor: "#E8EDF2", borderRadius: 10 },
  closeText: { color: "#18222F", fontSize: 12, fontWeight: "700" }, content: { padding: 20, paddingTop: 0, paddingBottom: 40 },
  card: { backgroundColor: "#fff", padding: 18, borderRadius: 18, borderWidth: 1, borderColor: "#E6EBF0" },
  label: { color: "#465364", fontSize: 12, lineHeight: 20, fontWeight: "700", marginBottom: 6 },
  input: { minHeight: 48, borderWidth: 1, borderColor: "#E6EBF0", backgroundColor: "#F6F7F9", borderRadius: 10, paddingHorizontal: 12, paddingVertical: 10, color: "#18222F", fontSize: 14, lineHeight: 23, marginBottom: 16 },
  multiline: { minHeight: 84 }, invalid: { borderColor: "#D13D3D" }, error: { color: "#D13D3D", fontSize: 12, lineHeight: 20, marginBottom: 14, marginTop: -10 },
  note: { color: "#748091", fontSize: 11, lineHeight: 19, marginBottom: 16 },
  save: { backgroundColor: "#F05A5A", borderRadius: 12, minHeight: 48, padding: 12, alignItems: "center", justifyContent: "center" },
  saveText: { color: "#fff", fontWeight: "800", fontSize: 14, lineHeight: 23 },
  cancel: { alignItems: "center", padding: 15 }, cancelText: { color: "#748091", fontSize: 12, lineHeight: 20 },
  pressed: { opacity: 0.7 }, disabled: { opacity: 0.5 },
});
